package com.asma.displaydate.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import java.text.SimpleDateFormat;
import java.util.Date;


@Controller

public class DateController {
	
	@RequestMapping("/date")
	public String date(Model model) {
		
		String dateformat = "EEEEE, 'the' dd 'of' MMMMM, yyyy";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateformat);
		String date = dateFormat.format(new Date());
		
		model.addAttribute("date", date);
		
		return "date.jsp";
		
	}
	
	

}
