
alert("this is time template");